var searchData=
[
  ['politician',['Politician',['../classPolitician.html#a334968deab19d05310a8d564299a030a',1,'Politician']]]
];
