var searchData=
[
  ['centipede',['Centipede',['../classCentipede.html',1,'Centipede'],['../classActor.html#a398752837eee9970ca00a3565e52c4daaca4c443e9d37143364c2760158033d08',1,'Actor::CENTIPEDE()'],['../classCentipede.html#ae0fed98579ba2b20049697c97de32cfb',1,'Centipede::Centipede()']]],
  ['centipede_2ecpp',['centipede.cpp',['../centipede_8cpp.html',1,'']]],
  ['centipede_2eh',['centipede.h',['../centipede_8h.html',1,'']]],
  ['chance_5fto_5fbeat_5fcentipede',['CHANCE_TO_BEAT_CENTIPEDE',['../classHero.html#a79603131508da3c95d82594ff29ccb32',1,'Hero']]],
  ['chance_5fto_5fbeat_5fmiss_5funiverse',['CHANCE_TO_BEAT_MISS_UNIVERSE',['../classHero.html#a13075687fe82d8eee2bd7ef77222ca4f',1,'Hero']]],
  ['chance_5fto_5fbeat_5fpolitician',['CHANCE_TO_BEAT_POLITICIAN',['../classHero.html#a8fe3d6c05946b15de5b08e912fe226fc',1,'Hero']]],
  ['chance_5fto_5fbeat_5fthe_5fdonald',['CHANCE_TO_BEAT_THE_DONALD',['../classHero.html#a470885608dec7243532ca656b52feead',1,'Hero']]]
];
