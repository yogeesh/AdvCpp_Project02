var searchData=
[
  ['author',['Author',['../log_8txt.html#a2153263aadf46404cd10eee1053d8cb2',1,'log.txt']]]
];
