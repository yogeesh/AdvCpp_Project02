var searchData=
[
  ['politician_2ecpp',['politician.cpp',['../politician_8cpp.html',1,'']]],
  ['politician_2eh',['politician.h',['../politician_8h.html',1,'']]]
];
