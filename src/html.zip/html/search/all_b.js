var searchData=
[
  ['politician',['Politician',['../classPolitician.html',1,'Politician'],['../classPolitician.html#a334968deab19d05310a8d564299a030a',1,'Politician::Politician()'],['../classActor.html#a398752837eee9970ca00a3565e52c4daa7c3965a675a848e7e3d0c28a9218e20a',1,'Actor::POLITICIAN()']]],
  ['politician_2ecpp',['politician.cpp',['../politician_8cpp.html',1,'']]],
  ['politician_2eh',['politician.h',['../politician_8h.html',1,'']]]
];
