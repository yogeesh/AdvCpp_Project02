var searchData=
[
  ['politician',['Politician',['../classPolitician.html',1,'']]]
];
