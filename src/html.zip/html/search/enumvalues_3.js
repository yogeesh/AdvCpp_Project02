var searchData=
[
  ['politician',['POLITICIAN',['../classActor.html#a398752837eee9970ca00a3565e52c4daa7c3965a675a848e7e3d0c28a9218e20a',1,'Actor']]]
];
