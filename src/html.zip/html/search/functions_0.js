var searchData=
[
  ['action',['action',['../classTrumpTower.html#a2eb063d540d428f2f41bf5264e67c283',1,'TrumpTower']]],
  ['actor',['Actor',['../classActor.html#abe57954a691a017c6ee051d6d21baf13',1,'Actor']]]
];
