var searchData=
[
  ['id',['id',['../classActor.html#a084438abd4bcb9d5e17b8ad75b0f5984',1,'Actor']]],
  ['insert',['insert',['../classFloor.html#aae2be662bce4dc3ca0c18e029d85d628',1,'Floor']]]
];
