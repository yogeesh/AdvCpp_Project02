var searchData=
[
  ['victory',['victory',['../classActor.html#a1595ffb3d753120a9e74eac0bd69adf1',1,'Actor::victory()'],['../classCentipede.html#a1b995576767d3eff9bfcac599ec35ddf',1,'Centipede::victory()'],['../classMissUniverse.html#aac659076d954d5342ba494a993eab2fd',1,'MissUniverse::victory()'],['../classPolitician.html#a7428489cb0380195cc5d74faeece6355',1,'Politician::victory()'],['../classReporter.html#ac0c496d5f8f3f56c71d2afe6ab53490e',1,'Reporter::victory()'],['../classSJW.html#af9bffa85da9c04559f38210f11a80c1d',1,'SJW::victory()'],['../classTheDonald.html#abee1d5bb4910c657ffd41fc745298cdc',1,'TheDonald::victory()']]]
];
