var searchData=
[
  ['defeat',['defeat',['../classActor.html#a0405c30d4ad11809647d2bf4e78026a7',1,'Actor::defeat()'],['../classCentipede.html#ae7cf6ce3b3b3ce66fe82986fd31d7be0',1,'Centipede::defeat()'],['../classMissUniverse.html#af8842e3ec345796fcdadca07a79442b0',1,'MissUniverse::defeat()'],['../classPolitician.html#a0734a1c1deed35b36b02f83b2c9ee46c',1,'Politician::defeat()'],['../classReporter.html#a6147cf4ee48d5c81e72538d39c79d228',1,'Reporter::defeat()'],['../classSJW.html#a04d480d0bedb684591a1a14d41b93257',1,'SJW::defeat()'],['../classTheDonald.html#ac6920f6026c3b0d91afbce90f6f07fad',1,'TheDonald::defeat()']]],
  ['defend',['defend',['../classHero.html#a7168d1fa26c3346cf0f541f4447bc05d',1,'Hero']]]
];
