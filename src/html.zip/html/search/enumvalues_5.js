var searchData=
[
  ['social_5fjustice_5fwarrior',['SOCIAL_JUSTICE_WARRIOR',['../classActor.html#a398752837eee9970ca00a3565e52c4daa6f51cf00ba9bc370ee69e35b1fb2c8aa',1,'Actor']]]
];
