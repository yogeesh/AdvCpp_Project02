var searchData=
[
  ['remove',['remove',['../classFloor.html#a728395aeeae56e45da8cb9b13066aed5',1,'Floor']]],
  ['reporter',['Reporter',['../classReporter.html#a7cfd771737b90ff52c361c1c898a8b6f',1,'Reporter']]],
  ['roll_5fdice',['roll_dice',['../classRNG.html#ad3340707ef6f70eeb2923572c2839b02',1,'RNG']]]
];
