var searchData=
[
  ['name',['name',['../classActor.html#a400c24cfb4609e95e869bfe970f386c5',1,'Actor::name()'],['../classCentipede.html#a9eb91c34048cb51599b5c3bcac6dfa64',1,'Centipede::NAME()'],['../classMissUniverse.html#a8030bea29113f33925240bdcce5efd45',1,'MissUniverse::NAME()'],['../classPolitician.html#a9092b26f16fe1c7b5f88a007ff62db82',1,'Politician::NAME()'],['../classReporter.html#a0e02a11312453ea2ad20cbcf32df478d',1,'Reporter::NAME()'],['../classSJW.html#a38d0a4a884536b96c3c9e7b5c32bf0fb',1,'SJW::NAME()'],['../classTheDonald.html#a5524e0abfd4ea1eb4f22f526f4583732',1,'TheDonald::NAME()']]],
  ['number',['number',['../classFloor.html#a30de5259aa79b701c36897502b9b6295',1,'Floor']]]
];
