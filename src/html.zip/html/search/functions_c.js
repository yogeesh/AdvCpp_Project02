var searchData=
[
  ['thedonald',['TheDonald',['../classTheDonald.html#a3e3d985e27af763356a7936d8bf190d8',1,'TheDonald']]],
  ['trumptower',['TrumpTower',['../classTrumpTower.html#a289ef64fd3602f7df558eeeda36ab237',1,'TrumpTower']]],
  ['ttexception',['TTException',['../classTTException.html#a1a7415151aeb69b2a0ce2c150c63e46a',1,'TTException']]],
  ['type',['type',['../classActor.html#a2be506fc6785b49d642a1b8f445c5c00',1,'Actor']]]
];
