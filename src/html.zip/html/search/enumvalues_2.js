var searchData=
[
  ['miss_5funiverse',['MISS_UNIVERSE',['../classActor.html#a398752837eee9970ca00a3565e52c4daacf7f8a23b2a3995ab6777cb142cec6dc',1,'Actor']]]
];
