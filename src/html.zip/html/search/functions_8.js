var searchData=
[
  ['name',['name',['../classActor.html#a400c24cfb4609e95e869bfe970f386c5',1,'Actor']]],
  ['number',['number',['../classFloor.html#a30de5259aa79b701c36897502b9b6295',1,'Floor']]]
];
