var searchData=
[
  ['west',['WEST',['../direction_8h.html#a224b9163917ac32fc95a60d8c1eec3aaae9449e8683a8199dad36b07a63b2f523',1,'direction.h']]],
  ['what',['what',['../classTTException.html#a89fb8e8d64f5a98813956334c5179c1f',1,'TTException']]]
];
